﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Npgsql;
using System;
using System.IO.Pipelines;
using System.Text.Json;
using System.Threading.Tasks;
using xbytechat.api;
using xbytechat.api.DTOs.Messages;
using xbytechat.api.Features.CampaignTracking.Models;
using xbytechat.api.Features.CRM.Models;
using xbytechat.api.Features.CRM.Services;
using xbytechat.api.Features.CTAFlowBuilder.Models;
using xbytechat.api.Features.CTAFlowBuilder.Services;
using xbytechat.api.Features.CustomeApi.Models;
using xbytechat.api.Features.CustomeApi.Services;
using xbytechat.api.Features.MessagesEngine.DTOs;
using xbytechat.api.Features.MessagesEngine.Services;
using xbytechat.api.Features.Tracking.DTOs;
using xbytechat.api.Features.Tracking.Models;
using xbytechat.api.Features.Tracking.Services;
using xbytechat.api.Features.Webhooks.Services.Resolvers;
using xbytechat.api.Helpers;
using xbytechat.api.Shared.TrackingUtils;

namespace xbytechat.api.Features.Webhooks.Services.Processors
{
    public class ClickWebhookProcessor : IClickWebhookProcessor
    {
        private readonly ILogger<ClickWebhookProcessor> _logger;
        private readonly IMessageIdResolver _messageIdResolver;
        private readonly ITrackingService _trackingService;
        private readonly AppDbContext _context;
        private readonly IMessageEngineService _messageEngine;
        private readonly ICTAFlowService _flowService;
        private readonly IFlowRuntimeService _flowRuntime;
        private readonly IContactProfileService _contactProfile;
        private readonly ICtaJourneyPublisher _journeyPublisher;
        private static readonly HashSet<string> StopKeywords = new(StringComparer.Ordinal)
        {
            "STOP",
            "UNSUBSCRIBE",
            "CANCEL",
            "END",
            "STOPALL"
        };

        private static readonly HashSet<string> StartKeywords = new(StringComparer.Ordinal)
        {
            "START",
            "UNSTOP",
            "SUBSCRIBE"
        };
        public ClickWebhookProcessor(
            ILogger<ClickWebhookProcessor> logger,
            IMessageIdResolver messageIdResolver,
            ITrackingService trackingService,
            AppDbContext context,
            IMessageEngineService messageEngine,
            ICTAFlowService flowService,
                        IFlowRuntimeService flowRuntime,
                         IContactProfileService contactProfile,
                          ICtaJourneyPublisher journeyPublisher
            )
        {
            _logger = logger;
            _messageIdResolver = messageIdResolver;
            _trackingService = trackingService;
            _context = context;
            _messageEngine = messageEngine;
            _flowService = flowService;
            _flowRuntime = flowRuntime;
            _contactProfile = contactProfile;
            _journeyPublisher = journeyPublisher;

        }

      

        public async Task ProcessClickAsync(JsonElement value)
        {
            _logger.LogWarning("📥 [ENTERED CLICK PROCESSOR]");

            try
            {
                if (!value.TryGetProperty("messages", out var messages) || messages.GetArrayLength() == 0)
                    return;

                // ── local helpers ─────────────────────────────────────────────────────────
                // NOTE: Keep provider normalization consistent across webhook/runtime paths.
                static string NormalizeProvider(string? raw)
                {
                    if (string.IsNullOrWhiteSpace(raw)) return string.Empty;
                    var p = raw.Trim().Replace("-", "_").Replace(" ", "_").ToUpperInvariant();
                    return p == "META" ? "META_CLOUD" : p;
                }
                static string Norm(string? s)
                {
                    if (string.IsNullOrWhiteSpace(s)) return string.Empty;
                    return string.Join(' ', s.Split(new[] { ' ', '\t', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
                                 .Trim()
                                 .ToLowerInvariant();
                }

                // canonical phone: keep only digits (matches how we store & search contacts)
                static string NormalizePhone(string? raw)
                    => new string((raw ?? string.Empty).Where(char.IsDigit).ToArray());

                static string NormalizeInboundPhone(string? raw)
                {
                    var digits = NormalizePhone(raw);
                    if (string.IsNullOrWhiteSpace(digits)) return string.Empty;

                    var normalized = PhoneNumberNormalizer.NormalizeToE164Digits("+" + digits, "IN");
                    return !string.IsNullOrWhiteSpace(normalized) ? normalized : digits;
                }

                // contacts[0].profile.name (Meta shape)
                static string? TryGetProfileName(JsonElement root)
                {
                    if (root.TryGetProperty("contacts", out var contactsEl) &&
                        contactsEl.ValueKind == JsonValueKind.Array &&
                        contactsEl.GetArrayLength() > 0)
                    {
                        var c0 = contactsEl[0];
                        if (c0.TryGetProperty("profile", out var profEl) &&
                            profEl.ValueKind == JsonValueKind.Object &&
                            profEl.TryGetProperty("name", out var nameEl) &&
                            nameEl.ValueKind == JsonValueKind.String)
                        {
                            var n = nameEl.GetString();
                            return string.IsNullOrWhiteSpace(n) ? null : n!.Trim();
                        }
                    }
                    return null;
                }

                // optional helper (kept for future use)
                static string ToKey(string? s)
                {
                    if (string.IsNullOrWhiteSpace(s)) return "unknown";
                    var t = s.Trim().ToLowerInvariant();
                    var sb = new System.Text.StringBuilder(t.Length);
                    foreach (var ch in t)
                    {
                        if (char.IsLetterOrDigit(ch)) sb.Append(ch);
                        else if (char.IsWhiteSpace(ch) || ch == '-' || ch == '_' || ch == '.') sb.Append('_');
                    }
                    var k = sb.ToString().Trim('_');
                    return string.IsNullOrEmpty(k) ? "unknown" : k;
                }
                // ──────────────────────────────────────────────────────────────────────────

                // read WA display number once (used as botId) – optional, not strictly required
                string botIdFromWebhook = "";
                if (value.TryGetProperty("metadata", out var md) &&
                    md.TryGetProperty("display_phone_number", out var dpnEl) &&
                    dpnEl.ValueKind == JsonValueKind.String)
                {
                    botIdFromWebhook = NormalizePhone(dpnEl.GetString());
                }

                foreach (var msg in messages.EnumerateArray())
                {
                    if (!msg.TryGetProperty("type", out var typeProp))
                        continue;

                    var nowUtc = DateTime.UtcNow;
                    if (msg.TryGetProperty("timestamp", out var tsProp))
                    {
                        long unixSeconds = 0;
                        if (tsProp.ValueKind == JsonValueKind.String)
                        {
                            var tsStr = tsProp.GetString();
                            if (!string.IsNullOrWhiteSpace(tsStr))
                                long.TryParse(tsStr, out unixSeconds);
                        }
                        else if (tsProp.ValueKind == JsonValueKind.Number)
                        {
                            tsProp.TryGetInt64(out unixSeconds);
                        }
                        if (unixSeconds > 0)
                            nowUtc = DateTimeOffset.FromUnixTimeSeconds(unixSeconds).UtcDateTime;
                    }

                    var type = typeProp.GetString();

                    string? clickMessageId = msg.TryGetProperty("id", out var idProp) ? idProp.GetString() : null;
                    clickMessageId = string.IsNullOrWhiteSpace(clickMessageId) ? null : clickMessageId.Trim();
                    string? originalMessageId = msg.TryGetProperty("context", out var ctx) && ctx.TryGetProperty("id", out var ctxId)
                        ? ctxId.GetString()
                        : null;

                    var fromRaw = msg.TryGetProperty("from", out var fromProp) ? (fromProp.GetString() ?? "") : "";
                    var fromDigits = NormalizeInboundPhone(fromRaw);
                    if (string.IsNullOrWhiteSpace(fromDigits))
                    {
                        _logger.LogWarning("⚠️ Click webhook skipped due to invalid sender phone. from={From}", fromRaw);
                        continue;
                    }

                    // ——— button label extraction
                    string? buttonText = null;
                    bool buttonKeyFromIdFallback = false;
                    if (string.Equals(type, "button", StringComparison.OrdinalIgnoreCase))
                    {
                        buttonText = msg.TryGetProperty("button", out var btn) &&
                                     btn.TryGetProperty("text", out var textProp)
                                       ? textProp.GetString()?.Trim()
                                       : null;
                    }
                    else if (string.Equals(type, "interactive", StringComparison.OrdinalIgnoreCase) &&
                             msg.TryGetProperty("interactive", out var interactive))
                    {
                        if (interactive.TryGetProperty("type", out var intrType) &&
                            string.Equals(intrType.GetString(), "button_reply", StringComparison.OrdinalIgnoreCase) &&
                            interactive.TryGetProperty("button_reply", out var br) &&
                            br.ValueKind == JsonValueKind.Object)
                        {
                            // Support both title and id:
                            // - Try title first (historical mapping uses visible text)
                            // - Fall back to id when title is missing (provider payload shape changes)
                            if (br.TryGetProperty("title", out var titleProp) && titleProp.ValueKind == JsonValueKind.String)
                            {
                                buttonText = titleProp.GetString()?.Trim();
                            }
                            else if (br.TryGetProperty("id", out var idKeyProp) && idKeyProp.ValueKind == JsonValueKind.String)
                            {
                                buttonText = idKeyProp.GetString()?.Trim();
                                buttonKeyFromIdFallback = !string.IsNullOrWhiteSpace(buttonText);
                            }
                        }
                        else if (interactive.TryGetProperty("list_reply", out var lr) &&
                                 lr.TryGetProperty("title", out var listTitleProp))
                        {
                            buttonText = listTitleProp.GetString()?.Trim();
                        }
                    }

                    if (string.IsNullOrWhiteSpace(buttonText))
                    {
                        _logger.LogDebug("ℹ️ Not a recognized click. type={Type}", type);
                        continue;
                    }
                    if (string.IsNullOrWhiteSpace(originalMessageId))
                    {
                        _logger.LogWarning("⚠️ Click received without context.id; using fallback business/contact resolution.");
                    }

                    _logger.LogInformation("🖱️ Button Click → From: {From}, ClickId: {ClickId}, OrigMsgId: {OrigId}, Text: {Text}",
                        fromDigits, clickMessageId, originalMessageId, buttonText);

                    // —— Try 1/2: resolve flow context from original message ids when present
                    var origin = !string.IsNullOrWhiteSpace(originalMessageId)
                        ? await _context.MessageLogs
                            .AsNoTracking()
                            .FirstOrDefaultAsync(m =>
                                m.MessageId == originalMessageId &&
                                m.CTAFlowConfigId != null &&
                                m.CTAFlowStepId != null)
                        : null;

                    Guid businessId = Guid.Empty;
                    Guid flowId = Guid.Empty;
                    Guid stepId = Guid.Empty;
                    string? bundleJson = null;
                    int? flowVersion = null;
                    var hasFlowContext = false;

                    Guid? campaignSendLogId = null; // link the click to the shown message
                    Guid? runId = null;             // copy from parent CSL when available

                    if (origin != null)
                    {
                        businessId = origin.BusinessId;
                        flowId = origin.CTAFlowConfigId!.Value;
                        stepId = origin.CTAFlowStepId!.Value;
                        bundleJson = origin.ButtonBundleJson;
                        flowVersion = origin.FlowVersion;

                        // Map back to CSL via MessageLogId or WAMID and fetch RunId
                        var cslInfo = await _context.CampaignSendLogs
                            .AsNoTracking()
                            .Where(csl => (csl.MessageLogId == origin.Id) || (csl.MessageId == originalMessageId))
                            .OrderByDescending(csl => csl.CreatedAt)
                            .Select(csl => new { csl.Id, csl.RunId })
                            .FirstOrDefaultAsync();

                        campaignSendLogId = cslInfo?.Id;
                        runId = cslInfo?.RunId;
                        hasFlowContext = true;
                    }
                    else if (!string.IsNullOrWhiteSpace(originalMessageId))
                    {
                        // —— Try 2: first campaign message (CampaignSendLogs)
                        var sendLog = await _context.CampaignSendLogs
                            .Include(sl => sl.Campaign)
                            .AsNoTracking()
                            .FirstOrDefaultAsync(sl => sl.MessageId == originalMessageId);

                        if (sendLog == null)
                        {
                            _logger.LogWarning("❌ No MessageLog or CampaignSendLog for original WAMID {Orig}", originalMessageId);
                        }
                        else
                        {
                            businessId = sendLog.BusinessId != Guid.Empty
                                ? sendLog.BusinessId
                                : (sendLog.Campaign?.BusinessId ?? Guid.Empty);

                            if (businessId == Guid.Empty)
                            {
                                _logger.LogWarning("❌ Could not resolve BusinessId for WAMID {Orig}", originalMessageId);
                            }
                            else
                            {
                                campaignSendLogId = sendLog.Id;
                                runId = sendLog.RunId;

                                if (sendLog.CTAFlowConfigId.HasValue && sendLog.CTAFlowStepId.HasValue)
                                {
                                    flowId = sendLog.CTAFlowConfigId.Value;
                                    stepId = sendLog.CTAFlowStepId.Value;
                                    hasFlowContext = true;
                                }
                                else if (sendLog.Campaign?.CTAFlowConfigId != null)
                                {
                                    flowId = sendLog.Campaign.CTAFlowConfigId.Value;

                                    var entry = await _context.CTAFlowSteps
                                        .Where(s => s.CTAFlowConfigId == flowId)
                                        .OrderBy(s => s.StepOrder)
                                        .Select(s => s.Id)
                                        .FirstOrDefaultAsync();

                                    if (entry == Guid.Empty)
                                    {
                                        _logger.LogWarning("❌ No entry step found for flow {Flow}", flowId);
                                    }
                                    else
                                    {
                                        stepId = entry;
                                        hasFlowContext = true;
                                    }
                                }
                                else
                                {
                                    _logger.LogWarning("❌ No flow context on CampaignSendLog for WAMID {Orig}", originalMessageId);
                                }

                                bundleJson = sendLog.ButtonBundleJson;
                            }
                        }
                    }

                    // —— Try 3: fallback business resolution by webhook display phone number
                    if (businessId == Guid.Empty && !string.IsNullOrWhiteSpace(botIdFromWebhook))
                    {
                        var phoneRows = await _context.WhatsAppPhoneNumbers
                            .AsNoTracking()
                            .Where(n => n.IsActive)
                            .Select(n => new { n.BusinessId, n.WhatsAppBusinessNumber })
                            .ToListAsync();

                        var bizHit = phoneRows.FirstOrDefault(n =>
                            NormalizePhone(n.WhatsAppBusinessNumber) == botIdFromWebhook);

                        if (bizHit != null)
                            businessId = bizHit.BusinessId;
                    }

                    if (businessId == Guid.Empty)
                    {
                        _logger.LogWarning("❌ Could not resolve BusinessId for click. context={Orig}, from={From}", originalMessageId, fromDigits);
                        continue;
                    }

                    var providerEventId = clickMessageId;
                    if (!string.IsNullOrWhiteSpace(providerEventId))
                    {
                        var alreadyProcessed = await _context.FlowExecutionLogs
                            .AsNoTracking()
                            .AnyAsync(x => x.BusinessId == businessId && x.ProviderEventId == providerEventId);

                        if (alreadyProcessed)
                        {
                            _logger.LogInformation("↩️ Duplicate click webhook ignored. businessId={BusinessId}, providerEventId={ProviderEventId}", businessId, providerEventId);
                            continue;
                        }
                    }

                    // ─────────────────────────────────────────────────────────────
                    // ✅ UPSERT PROFILE NAME (create-or-update) *before* next step
                    //    ensure we look up by digits-only phone.
                    // ─────────────────────────────────────────────────────────────
                    Contact? trackedContact = null;
                    try
                    {
                        var profileName = TryGetProfileName(value);
                        if (!string.IsNullOrWhiteSpace(profileName))
                        {
                            trackedContact = await _context.Contacts
                                .FirstOrDefaultAsync(c => c.BusinessId == businessId &&
                                                          (c.PhoneNumber == fromDigits || c.PhoneNumber == fromRaw));

                            if (trackedContact == null)
                            {
                                profileName = profileName ?? "User";
                                trackedContact = new Contact
                                {
                                    Id = Guid.NewGuid(),
                                    BusinessId = businessId,
                                    PhoneNumber = fromDigits, // store canonical
                                    Name = profileName,
                                    ProfileName = profileName,
                                    ProfileNameUpdatedAt = nowUtc,
                                    CreatedAt = nowUtc,
                                };
                                _context.Contacts.Add(trackedContact);
                                await _context.SaveChangesAsync();
                                _logger.LogInformation("👤 Created contact + stored WA profile '{Name}' for {Phone} (biz {Biz})",
                                    profileName, fromDigits, businessId);
                            }
                            else
                            {
                                var changed = false;

                                if (!string.Equals(trackedContact.ProfileName, profileName, StringComparison.Ordinal))
                                {
                                    trackedContact.ProfileName = profileName;
                                    trackedContact.ProfileNameUpdatedAt = nowUtc;
                                    changed = true;
                                }

                                if (string.IsNullOrWhiteSpace(trackedContact.Name) ||
                                    trackedContact.Name == "WhatsApp User" ||
                                    trackedContact.Name == trackedContact.PhoneNumber)
                                {
                                    if (!string.Equals(trackedContact.Name, profileName, StringComparison.Ordinal))
                                    {
                                        trackedContact.Name = profileName;
                                        changed = true;
                                    }
                                }

                                if (changed)
                                {
                                    trackedContact.ProfileNameUpdatedAt = nowUtc;
                                    await _context.SaveChangesAsync();
                                    _logger.LogInformation("👤 Updated WA profile name to '{Name}' for {Phone} (biz {Biz})",
                                        profileName, fromDigits, businessId);
                                }
                            }
                        }
                    }
                    catch (Exception exProf)
                    {
                        _logger.LogWarning(exProf, "⚠️ Failed to upsert WA profile name on click webhook.");
                    }

                    if (trackedContact == null)
                    {
                        trackedContact = await _context.Contacts
                            .FirstOrDefaultAsync(c => c.BusinessId == businessId &&
                                                      (c.PhoneNumber == fromDigits || c.PhoneNumber == fromRaw));
                    }

                    if (trackedContact != null)
                    {
                        // Treat interactive click as inbound activity and reuse inbox reopen logic from InboundMessageProcessor.
                        trackedContact.LastInboundAt = nowUtc;

                        var inboxStatus = (trackedContact.InboxStatus ?? string.Empty).Trim();
                        if (string.Equals(inboxStatus, "Closed", StringComparison.OrdinalIgnoreCase) ||
                            trackedContact.IsArchived ||
                            !trackedContact.IsActive)
                        {
                            trackedContact.InboxStatus = "Open";
                            trackedContact.IsArchived = false;
                            trackedContact.IsActive = true;
                        }

                        await _context.SaveChangesAsync();
                    }
                    else
                    {
                        _logger.LogWarning("⚠️ Contact not found for click activity update. biz={Biz} from={From}", businessId, fromDigits);
                    }

                    var complianceKeyword = NormalizeKeywordToken(buttonText);
                    if (trackedContact != null && IsStopKeyword(complianceKeyword))
                    {
                        trackedContact.OptStatus = ContactOptStatus.OptedOut;
                        trackedContact.OptStatusUpdatedAt = nowUtc;
                        trackedContact.OptOutReason = "KeywordStop";
                        await _context.SaveChangesAsync();

                        _logger.LogInformation(
                            "Compliance interceptor applied STOP on interactive click. biz={Biz} contactId={ContactId} phone={Phone}",
                            businessId,
                            trackedContact.Id,
                            trackedContact.PhoneNumber);
                        continue;
                    }

                    if (trackedContact != null && IsStartKeyword(complianceKeyword))
                    {
                        trackedContact.OptStatus = ContactOptStatus.OptedIn;
                        trackedContact.OptStatusUpdatedAt = nowUtc;
                        trackedContact.OptOutReason = null;
                        await _context.SaveChangesAsync();

                        _logger.LogInformation(
                            "Compliance interceptor applied START on interactive click. biz={Biz} contactId={ContactId} phone={Phone}",
                            businessId,
                            trackedContact.Id,
                            trackedContact.PhoneNumber);
                        continue;
                    }

                    var isOptedOutContact = trackedContact?.OptStatus == ContactOptStatus.OptedOut;

                    if (!hasFlowContext)
                    {
                        _logger.LogWarning("⚠️ Click context unresolved. Activity updated and flow execution skipped. biz={Biz} from={From} orig={Orig}",
                            businessId, fromDigits, originalMessageId);
                        continue;
                    }

                    // —— Map clicked text -> button index via the shown bundle
                    short? buttonIndex = null;
                    FlowBtnBundleNode? hit = null;

                    if (!string.IsNullOrWhiteSpace(bundleJson))
                    {
                        try
                        {
                            var nodes = System.Text.Json.JsonSerializer
                                .Deserialize<List<FlowBtnBundleNode>>(bundleJson) ?? new();

                            // Match by visible text OR, if inbound key came from id fallback, by stored value/payload (n.v).
                            // This protects routing when WhatsApp stops sending the title consistently.
                            hit =
                                (buttonKeyFromIdFallback
                                    ? nodes.FirstOrDefault(n => string.Equals(n.v ?? "", buttonText, StringComparison.OrdinalIgnoreCase))
                                      ?? nodes.FirstOrDefault(n => Norm(n.v) == Norm(buttonText))
                                      ?? nodes.FirstOrDefault(n => string.Equals(n.t ?? "", buttonText, StringComparison.OrdinalIgnoreCase))
                                      ?? nodes.FirstOrDefault(n => Norm(n.t) == Norm(buttonText))
                                    : nodes.FirstOrDefault(n => string.Equals(n.t ?? "", buttonText, StringComparison.OrdinalIgnoreCase))
                                      ?? nodes.FirstOrDefault(n => Norm(n.t) == Norm(buttonText)));

                            if (hit != null)
                                buttonIndex = (short)hit.i;
                        }
                        catch (Exception ex)
                        {
                            _logger.LogWarning(ex, "⚠️ Failed to parse ButtonBundleJson");
                        }
                    }

                    // —— Fallback: find link by TEXT for this step
                    FlowButtonLink? linkMatchedByText = null;
                    if (buttonIndex == null)
                    {
                        var stepLinks = await _context.FlowButtonLinks
                            .Where(l => l.CTAFlowStepId == stepId)
                            .OrderBy(l => l.ButtonIndex)
                            .ToListAsync();

                        if (stepLinks.Count > 0)
                        {
                            linkMatchedByText = stepLinks.FirstOrDefault(l =>
                                string.Equals(l.ButtonText ?? "", buttonText, StringComparison.OrdinalIgnoreCase))
                                ?? stepLinks.FirstOrDefault(l => Norm(l.ButtonText) == Norm(buttonText));

                            // If the inbound click was keyed by button_reply.id, also allow matching by stored ButtonValue.
                            if (linkMatchedByText == null && buttonKeyFromIdFallback)
                            {
                                linkMatchedByText = stepLinks.FirstOrDefault(l =>
                                    string.Equals(l.ButtonValue ?? "", buttonText, StringComparison.OrdinalIgnoreCase))
                                    ?? stepLinks.FirstOrDefault(l => Norm(l.ButtonValue) == Norm(buttonText));
                            }

                            if (linkMatchedByText == null && stepLinks.Count == 1)
                            {
                                linkMatchedByText = stepLinks[0];
                                _logger.LogInformation("🟨 Falling back to single available link for step {Step}", stepId);
                            }

                            if (linkMatchedByText != null)
                            {
                                buttonIndex = (short?)linkMatchedByText.ButtonIndex;
                                _logger.LogInformation("✅ Mapped click by TEXT to index {Idx} (flow={Flow}, step={Step})",
                                    buttonIndex, flowId, stepId);
                            }
                        }
                    }

                    if (buttonIndex == null)
                    {
                        _logger.LogInformation("🟡 Button text not found in bundle or flow links. Ref={Ref}, Text='{Text}'",
                            originalMessageId, buttonText);
                        continue;
                    }

                    // —— Prefer exact link by index; otherwise use the text-matched link
                    var link = await _flowService.GetLinkAsync(flowId, stepId, buttonIndex.Value)
                               ?? linkMatchedByText;

                    if (link == null)
                    {
                        _logger.LogInformation("🟡 No button link for (flow={Flow}, step={Step}, idx={Idx})",
                            flowId, stepId, buttonIndex);
                        continue;
                    }

                    // —— Resolve index + step name (for logging)
                    short resolvedIndex = buttonIndex ?? Convert.ToInt16(link.ButtonIndex);
                    var stepName = await _context.CTAFlowSteps
                        .Where(s => s.Id == stepId)
                        .Select(s => s.TemplateToSend)
                        .FirstOrDefaultAsync() ?? string.Empty;

                    // ————————————————
                    // 📝 WRITE CLICK LOG (always, even if terminal)
                    // ————————————————
                    try
                    {
                        var clickExec = new FlowExecutionLog
                        {
                            Id = Guid.NewGuid(),
                            BusinessId = businessId,
                            FlowId = flowId,
                            StepId = stepId,
                            StepName = stepName,
                            CampaignSendLogId = campaignSendLogId,
                            MessageLogId = origin?.Id,
                            ContactPhone = fromDigits,      // digits-only
                            ButtonIndex = resolvedIndex,
                            TriggeredByButton = buttonText,
                            TemplateName = null,
                            TemplateType = "quick_reply",
                            Success = true,
                            ExecutedAt = nowUtc,
                            RequestId = Guid.NewGuid(),
                            ProviderEventId = providerEventId,
                            RunId = runId
                        };

                        _context.FlowExecutionLogs.Add(clickExec);
                        await _context.SaveChangesAsync();
                    }
                    catch (DbUpdateException exSave) when (
                        exSave.InnerException is PostgresException pg &&
                        pg.SqlState == PostgresErrorCodes.UniqueViolation)
                    {
                        _logger.LogInformation("↩️ Duplicate click webhook ignored at DB guard. businessId={BusinessId}, providerEventId={ProviderEventId}",
                            businessId, providerEventId);
                        continue;
                    }
                    catch (Exception exSave)
                    {
                        _logger.LogWarning(exSave, "⚠️ Failed to persist FlowExecutionLog (click). Continuing…");
                    }

                    // ===== RUNNING CTA JOURNEY STATE UPSERT (ONLY IF THIS BIZ IS CONFIGURED) =====
                    string runningJourney;

                    // Check once if this business is configured to receive CTAJourney.
                    // IMPORTANT: Some deployments may not have the CustomerWebhookConfigs table yet; this must not block click → next-template sends.
                    bool shouldTrackState = false;
                    try
                    {
                        shouldTrackState = await _context.CustomerWebhookConfigs
                            .AsNoTracking()
                            .AnyAsync(x => x.BusinessId == businessId && x.IsActive);
                    }
                    catch (Npgsql.PostgresException pgEx) when (string.Equals(pgEx.SqlState, "42P01", StringComparison.Ordinal))
                    {
                        // 42P01 = undefined_table
                        _logger.LogWarning(pgEx,
                            "⚠️ CustomerWebhookConfigs table missing; skipping CTAJourney state tracking. biz={Biz} flow={Flow} step={Step} to={To}",
                            businessId, flowId, stepId, fromDigits);
                        shouldTrackState = false;
                    }
                    catch (Exception exTrack)
                    {
                        _logger.LogWarning(exTrack,
                            "⚠️ Failed to check CustomerWebhookConfigs; skipping CTAJourney state tracking. biz={Biz} flow={Flow} step={Step} to={To}",
                            businessId, flowId, stepId, fromDigits);
                        shouldTrackState = false;
                    }

                    if (shouldTrackState)
                    {
                        try
                        {
                            // load current state for (business, flow, phone)
                            var state = await _context.ContactJourneyStates
                                .SingleOrDefaultAsync(s =>
                                    s.BusinessId == businessId &&
                                    s.FlowId == flowId &&
                                    s.ContactPhone == fromDigits);

                            if (state == null)
                            {
                                // first click -> start with this button text (original casing)
                                state = new ContactJourneyState
                                {
                                    Id = Guid.NewGuid(),
                                    BusinessId = businessId,
                                    FlowId = flowId,
                                    ContactPhone = fromDigits,
                                    JourneyText = buttonText ?? string.Empty,
                                    ClickCount = 1,
                                    LastButtonText = buttonText,
                                    CreatedAt = nowUtc,
                                    UpdatedAt = nowUtc
                                };
                                _context.ContactJourneyStates.Add(state);
                                await _context.SaveChangesAsync();
                                runningJourney = state.JourneyText;
                                _logger.LogInformation("🧵 Journey init: {Journey} (biz={Biz}, flow={Flow}, phone={Phone})",
                                    runningJourney, businessId, flowId, fromDigits);
                            }
                            else
                            {
                                // append EVERY press (duplicates allowed), keep original casing
                                var parts = (state.JourneyText ?? string.Empty)
                                    .Split('/', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                                    .ToList();

                                if (!string.IsNullOrWhiteSpace(buttonText))
                                    parts.Add(buttonText!);

                                // cap growth
                                const int cap = 15;
                                if (parts.Count > cap) parts = parts.Skip(parts.Count - cap).ToList();

                                state.JourneyText = string.Join('/', parts);
                                state.ClickCount += 1;
                                state.LastButtonText = buttonText;
                                state.UpdatedAt = nowUtc;

                                await _context.SaveChangesAsync();
                                runningJourney = state.JourneyText ?? string.Empty;

                                _logger.LogInformation("🧵 Journey update: {Journey} (biz={Biz}, flow={Flow}, phone={Phone})",
                                    runningJourney, businessId, flowId, fromDigits);
                            }
                        }
                        catch (Exception exState)
                        {
                            _logger.LogWarning(exState, "⚠️ Failed to upsert ContactJourneyState.");
                            // fall back to this click only
                            runningJourney = buttonText ?? string.Empty;
                        }
                    }
                    else
                    {
                        // Business not configured → do NOT save any state. Just use the current button for emit.
                        runningJourney = buttonText ?? string.Empty;
                    }
                    // ===== END RUNNING CTA JOURNEY STATE UPSERT =====

                    // ===== CTAJourney EMIT (running journey) =====
                    try
                    {
                        // contact (for userName / userPhone)
                        var contact = await _context.Contacts
                            .AsNoTracking()
                            .FirstOrDefaultAsync(c => c.BusinessId == businessId && c.PhoneNumber == fromDigits);

                        // Prefer sender from the originating send (keeps the same WABA)
                        string? senderProvider = null;
                        string? senderPhoneNumberId = null;

                        if (campaignSendLogId.HasValue)
                        {
                            var originSend = await _context.CampaignSendLogs
                                .AsNoTracking()
                                .Include(s => s.Campaign)
                                .Where(s => s.Id == campaignSendLogId.Value)
                                .Select(s => new { s.Campaign.Provider, s.Campaign.PhoneNumberId })
                                .FirstOrDefaultAsync();

                            senderProvider = originSend?.Provider;
                            senderPhoneNumberId = originSend?.PhoneNumberId;
                        }
                        if (string.IsNullOrWhiteSpace(senderPhoneNumberId) && origin?.CampaignId != null)
                        {
                            var originCamp = await _context.Campaigns
                                .AsNoTracking()
                                .Where(c => c.Id == origin.CampaignId.Value)
                                .Select(c => new { c.Provider, c.PhoneNumberId })
                                .FirstOrDefaultAsync();

                            senderProvider ??= originCamp?.Provider;
                            senderPhoneNumberId = originCamp?.PhoneNumberId;
                        }

                        // Map PhoneNumberId -> WhatsAppBusinessNumber, or choose a default for the same provider
                        string? waBusinessNumber = null;

                        if (!string.IsNullOrWhiteSpace(senderPhoneNumberId))
                        {
                            waBusinessNumber = await _context.WhatsAppPhoneNumbers
                                .AsNoTracking()
                                .Where(n => n.BusinessId == businessId && n.PhoneNumberId == senderPhoneNumberId)
                                .Select(n => n.WhatsAppBusinessNumber)
                                .FirstOrDefaultAsync();
                        }

                        if (string.IsNullOrWhiteSpace(waBusinessNumber))
                        {
                            var row = await _context.WhatsAppPhoneNumbers
                                .AsNoTracking()
                                .Where(n => n.BusinessId == businessId &&
                                            n.IsActive &&
                                            (string.IsNullOrEmpty(senderProvider) || n.Provider == senderProvider))
                                .OrderByDescending(n => n.IsDefault)
                                .ThenByDescending(n => n.UpdatedAt ?? n.CreatedAt)
                                .Select(n => new { n.PhoneNumberId, n.WhatsAppBusinessNumber })
                                .FirstOrDefaultAsync();

                            senderPhoneNumberId ??= row?.PhoneNumberId;
                            waBusinessNumber = row?.WhatsAppBusinessNumber;
                        }

                        var dto = CtaJourneyMapper.Build(
                            journeyKey: runningJourney,                      // running state with original casing
                            contact: contact,
                            profileName: contact?.ProfileName ?? contact?.Name,
                            userId: null,
                            phoneNumberId: waBusinessNumber,                 // publish WA display number as bot id
                            businessDisplayPhone: waBusinessNumber,          // same as above
                            categoryBrowsed: null,
                            productBrowsed: null
                        );

                        await _journeyPublisher.PublishAsync(businessId, dto, CancellationToken.None);
                        _logger.LogInformation("📤 CTAJourney posted (running): {Journey} (biz={Biz}, phone={Phone})",
                            dto.CTAJourney, businessId, dto.userPhone);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "⚠️ Failed to post CTAJourney (click). Continuing…");
                    }
                    // ===== end CTAJourney EMIT =====

                    if (isOptedOutContact)
                    {
                        _logger.LogInformation(
                            "Compliance: contact is opted out; click activity logged but flow execution skipped. biz={Biz} phone={Phone}",
                            businessId,
                            fromDigits);
                        continue;
                    }

                    // —— If terminal/URL button: already logged the click
                    if (link.NextStepId == null)
                    {
                        _logger.LogInformation("🔚 Terminal/URL button: no NextStepId. flow={Flow}, step={Step}, idx={Idx}, text='{Text}'",
                            flowId, stepId, resolvedIndex, link.ButtonText);
                        continue;
                    }

                    if (_flowRuntime == null)
                    {
                        _logger.LogError("❌ _flowRuntime is null. Cannot execute next step. flow={Flow}, step={Step}, idx={Idx}", flowId, stepId, resolvedIndex);
                        continue;
                    }

                    // —— 🔎 Resolve sender from the originating campaign/send (use SAME WABA) for next step
                    string? providerFromCampaign = null;
                    string? phoneNumberIdFromCampaign = null;

                    if (campaignSendLogId.HasValue)
                    {
                        var originSend = await _context.CampaignSendLogs
                            .AsNoTracking()
                            .Include(s => s.Campaign)
                            .Where(s => s.Id == campaignSendLogId.Value)
                            .Select(s => new
                            {
                                s.Campaign.Provider,
                                s.Campaign.PhoneNumberId
                            })
                            .FirstOrDefaultAsync();

                        providerFromCampaign = originSend?.Provider;
                        phoneNumberIdFromCampaign = originSend?.PhoneNumberId;
                    }
                    else if (origin != null && origin.CampaignId.HasValue)
                    {
                        var originCamp = await _context.Campaigns
                            .AsNoTracking()
                            .Where(c => c.Id == origin.CampaignId.Value)
                            .Select(c => new { c.Provider, c.PhoneNumberId })
                            .FirstOrDefaultAsync();

                        providerFromCampaign = originCamp?.Provider;
                        phoneNumberIdFromCampaign = originCamp?.PhoneNumberId;
                    }

                    // —— Execute next (carry sender forward)
                    var ctxObj = new NextStepContext
                    {
                        BusinessId = businessId,
                        FlowId = flowId,
                        Version = flowVersion ?? 1,
                        SourceStepId = stepId,
                        TargetStepId = link.NextStepId!.Value,
                        ButtonIndex = resolvedIndex,
                        MessageLogId = origin?.Id ?? Guid.Empty,
                        ContactPhone = fromDigits,     // digits-only
                        RequestId = Guid.NewGuid(),
                        ClickedButton = link,

                        // carry same sender into the next step
                        Provider = string.IsNullOrWhiteSpace(providerFromCampaign) ? null : NormalizeProvider(providerFromCampaign),
                        PhoneNumberId = phoneNumberIdFromCampaign,
                        AlwaysSend = true // force runtime to send even if it’s a loopback/same step
                    };

                     try
                     {
                         var result = await _flowRuntime.ExecuteNextAsync(ctxObj);

                         if (!result.Success)
                         {
                             // Observability: webhook must return 200, but failures must not be silent.
                             _logger.LogWarning(
                                 "❌ ExecuteNextAsync returned failure biz={Biz} phone={Phone} flow={Flow} step={Step} targetStep={Target} idx={Idx} btn='{Btn}' err={Err}",
                                 businessId, fromDigits, ctxObj.FlowId, ctxObj.SourceStepId, ctxObj.TargetStepId, ctxObj.ButtonIndex, buttonText, result.Error);
                         }

                         if (result.Success && !string.IsNullOrWhiteSpace(result.RedirectUrl))
                         {
                             _logger.LogInformation("🔗 URL button redirect (logical): {Url}", result.RedirectUrl);
                         }
                     }
                    catch (Exception exRun)
                    {
                        _logger.LogError(exRun,
                            "❌ ExecuteNextAsync failed. ctx: flow={Flow} step={Step} next={Next} idx={Idx} from={From} orig={Orig} text='{Text}'",
                            ctxObj.FlowId, ctxObj.SourceStepId, ctxObj.TargetStepId, ctxObj.ButtonIndex, fromDigits, originalMessageId, buttonText);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Failed to process CTA button click.");
            }
        }

        private sealed class FlowBtnBundleNode
        {
            public int i { get; init; }
            public string? t { get; init; }   // button text/title
            public string? ty { get; init; }  // button type (URL/QUICK_REPLY/FLOW)
            public string? v { get; init; }   // value/payload (e.g., URL)
            public Guid? ns { get; init; }    // next step id
        }
        private static string ToKey(string? s)
        {
            if (string.IsNullOrWhiteSpace(s)) return "unknown";
            // letters/digits → lower, spaces/._- → underscore, strip the rest
            var chars = s.Trim().ToLowerInvariant()
                .Select(ch => char.IsLetterOrDigit(ch) ? ch : '_')
                .ToArray();
            var key = new string(chars);
            // squeeze duplicate underscores
            while (key.Contains("__")) key = key.Replace("__", "_");
            return key.Trim('_');
        }

        private static string NormalizeKeywordToken(string? text)
        {
            if (string.IsNullOrWhiteSpace(text)) return string.Empty;

            var firstToken = text.Trim()
                .Split(new[] { ' ', '\t', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                .FirstOrDefault() ?? string.Empty;

            var trimmed = firstToken.Trim().Trim('.', ',', '!', '?', ';', ':', '"', '\'', '(', ')', '[', ']', '{', '}');
            return trimmed.ToUpperInvariant();
        }

        private static bool IsStopKeyword(string normalizedText) => StopKeywords.Contains(normalizedText);

        private static bool IsStartKeyword(string normalizedText) => StartKeywords.Contains(normalizedText);

    }
}
